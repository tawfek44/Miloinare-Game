﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace milionir
{
    public partial class Form5 : Form
    {
        SoundPlayer musik = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\musik.wav");
        public Form5(string text)
        {
            InitializeComponent();
            label3.Text = text;
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            musik.PlayLooping();
            this.Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
