﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace milionir
{
    
    public partial class Form7 : Form
    {
        int c = 0;
        SoundPlayer start = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\oh.wav");
        SoundPlayer replace = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\per.wav");
        SoundPlayer firework = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\firework.wav");
        SoundPlayer fire1 = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\fire10.wav");
        public Form7()
        {
            InitializeComponent();
            //start.PlayLooping();
            timer1.Start();
            firework.PlayLooping();
            fire1.PlayLooping();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            start.Stop();
            firework.Stop();
            fire1.Stop();
            replace.PlayLooping();
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }
        int x = 0 , y=0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if(c==0)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire.jpg");
            else if(c==1)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire1.jpg");
            else if(c==2)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire2.jpg");
            else if(c==3)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire3.jpg");
            else if (c == 4)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire4.jpg");
            else if (c == 5)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire5.jpg");
            else if (c == 6)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire6.jpg");
            else if (c == 7)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire7.jpg");
            else if (c == 8)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire8.jpg");
            else if (c == 9)
                pictureBox2.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fire9.jpg");
            c++;
            if (c == 9)
                c = 0;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
