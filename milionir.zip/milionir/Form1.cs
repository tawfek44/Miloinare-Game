﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace milionir
{
    public partial class Form1 : Form
    {
        SoundPlayer start = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\Start.wav");
        SoundPlayer beg = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\beggening.wav");
        
        int c = 3 , s=0;
        public Form1()
        {
            InitializeComponent();
            timer2.Start();
            start.PlayLooping();
         
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\1.png");
            timer1.Start();
            timer2.Stop();
            beg.Play();
        }

        private void flatButton3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void flatMini1_Click(object sender, EventArgs e)
        {

        }

        private void flatClose1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            c--;
            if (c == 0)
            {
                start.Stop();
                Form2 f = new Form2();
                f.ShowDialog();
                this.Hide();
            }
        }

        private void flatButton2_Click(object sender, EventArgs e)
        {
            Form6 f = new Form6();
            f.ShowDialog();
            this.Hide();
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            s++;
            if (s == 1)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\1.png");
            else if (s == 2)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\2.png");
            else if (s == 3)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\3.png");
            else if (s == 4)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\4.png");
            else if (s == 5)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\5.png");
            else if (s == 6)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\6.png");
            else if (s == 7)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\7.png");
            else if (s == 8)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\8.png");
            else if (s == 9)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\9.png");
            else if (s == 10)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\10.png");
            else if (s == 11)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\11.png");
            else if (s == 12)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\12.png");
            else if (s == 13)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\13.png");
            else if (s == 14)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\14.png");
            else if (s == 15)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\15.png");
            else if (s == 16)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\16.png");
            else if (s == 17)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\17.png");
            else if (s == 18)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\New folder\18.png");
            else if (s == 19)
                s = 0;
        }
    }
}
