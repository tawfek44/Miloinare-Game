﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Media;
namespace milionir
{
    public partial class Form2 : Form
    {
        SoundPlayer zero = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\0shek.wav");
        SoundPlayer thaus = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\1000shek.wav");
        SoundPlayer musik = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\musik.wav");
        SoundPlayer start = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\firstquestion.wav");
        SoundPlayer fals = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\false.wav");
        SoundPlayer contact = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\contact.wav");
        SoundPlayer firstquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\real.wav");
        SoundPlayer secondquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\2real.wav");
        SoundPlayer thirdquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\500.wav");
        SoundPlayer fourthquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\5real.wav");
        SoundPlayer fifthquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\1000.wav");
        SoundPlayer sixquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\2000.wav");
        SoundPlayer sevenquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\4alaf.wav");
        SoundPlayer eightquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\8000.wav");
        SoundPlayer ninequestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\9.wav");
        SoundPlayer tenquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\1011.wav");
        SoundPlayer elevenquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\64000alf.wav");
        SoundPlayer fourteenquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\milion.wav");
        SoundPlayer fifteenquestion = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\مليون.wav");
        //timer1  //timer2   //timer3  //timer4 //timer5  //timer6 //timer7
        int c = 29 ,   s=3 ,     d=2      , m=6,     b=3  , p=5  ,     n=4      , asaad;
             //help    //button
        bool x = true, y = true,retrn=true, notavilable=true, clickbutton1 = false, clickbutton2 = false, clickbutton3 = false, clickbutton4 = false , people=false;
       //بسم الله الرحمن الرحيم
        string answer;
        //map 1 for question And Correct Answer 
        Dictionary <int , List<string>> map1=new Dictionary<int,List<string>>();
        List<string> vector1 = new List<string>();
        // map2 For All Answer
        Dictionary<int, List<string>> map2 = new Dictionary<int, List<string>>();
        List<string> vector2 = new List<string>();
        int  mo=0 , momo=0 , a;
        List<int> comrandom = new List<int>();
        Random rnd = new Random();
        
        public Form2()
        {
            InitializeComponent();
            start.Play();
            using (StreamReader read1 = new StreamReader(@"E:\kolia\My PRojet\ds\milionare Ui\milionir\Question.txt", Encoding.Default))
            {
                string text;
                while (!read1.EndOfStream)
                {
                    text = read1.ReadLine();
                    vector1.Add(text);
                    mo++;
                    if (mo == 2)
                    {
                        momo++;
                        map1[momo] = new List<string>(vector1);
                        mo = 0;
                        vector1.Clear();
                    }
                }
            }
            int g = 0, g1 = 0;
            using (StreamReader read = new StreamReader(@"E:\kolia\My PRojet\ds\milionare Ui\milionir\Answer.txt", Encoding.Default))
            {
                string txt;
                while (!read.EndOfStream)
                {
                    g++;
                    txt = read.ReadLine();
                    vector2.Add(txt);
                    if (g == 4)
                    {
                        g1++;
                        map2[g1] =new List<string> (vector2);
                        g = 0;
                        vector2.Clear();
                    }
                }
            }

            a = rnd.Next(1, 40);
            comrandom.Add(a);
            Question.ButtonText = map1[a][0];
            answer = map1[a][1];
            FirstAnswer.ButtonText = map2[a][0];
            SecondAnswer.ButtonText = map2[a][1];
            ThirdAnswer.ButtonText = map2[a][2];
            FourthAnsweer.ButtonText = map2[a][3];
            
            timer1.Start();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (x)
            {
                    if (notavilable)
                    {
                        timer5.Start();
                        pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\0.jpg");
                        pictureBox9.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\people.jpg");
                        notavilable = false;
                        people = true;
                    }
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (x)
            {
                if (retrn)
                {
                    contact.Play();
                    pictureBox7.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\phone.jpg");
                    timer6.Start();
                    retrn = false;
                } 
            }
        }
        bool fifty = true , first=true , second=true , third=true , fourth=true;
        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (x)
            {
                if (fifty)
                {
                    pictureBox8.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\fifty.jpg");

                    if (FirstAnswer.ButtonText == answer)
                        asaad = 0;
                    else if (SecondAnswer.ButtonText == answer)
                        asaad = 1;
                    else if (ThirdAnswer.ButtonText == answer)
                        asaad = 2;
                    else if (FourthAnsweer.ButtonText == answer)
                        asaad = 3;
                    if ( asaad == 0)
                    {
                        second = false;
                        third = false;
                        SecondAnswer.ButtonText = "";
                        ThirdAnswer.ButtonText = "";
                    }
                    else if ( asaad == 1)
                    {
                        FirstAnswer.ButtonText = "";
                        FourthAnsweer.ButtonText = "";
                    }
                    else if ( asaad == 2)
                    {
                        first = false;
                        second = false;
                        FirstAnswer.ButtonText = "";
                        SecondAnswer.ButtonText = "";
                    }
                    else if ( asaad == 3)
                    {
                        first = false;
                        third = false;
                        FirstAnswer.ButtonText = "";
                        ThirdAnswer.ButtonText = "";
                    }
                    fifty = false;
                }
            }

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (x)
            {
                if (DialogResult.Yes == MessageBox.Show("هل أنت متأكد أنك تريد الإنسحاب ؟", "الانسحاب", MessageBoxButtons.YesNo))
                {
                    timer1.Stop();
                    this.Hide();
                    if (Score >= 0 && Score <= 4)
                    {
                        zero.Play();
                        Form4 obj = new Form4(@"E:\kolia\My PRojet\ds\milionare Ui\0..jpg");
                        obj.Show();
                        this.Close();
                    }
                    else if (Score >= 5 && Score <= 9)
                    {
                        thaus.Play();
                        Form4 obj = new Form4(@"E:\kolia\My PRojet\ds\milionare Ui\Alf.jpg");
                        obj.Show();
                        this.Close();
                    }
                    else if (Score >= 10 && Score <= 15)
                    {
                        Form4 obj = new Form4(@"E:\kolia\My PRojet\ds\milionare Ui\32alf.jpg");
                        obj.Show();
                        this.Close();
                    }
                    
                }
                
            }
        }

        private void flatButton3_Click(object sender, EventArgs e)
        {

        }

        private void flatButton4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
        
        private void label3_Click(object sender, EventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Score == 0)
            {
                if (c == 24)
                    musik.PlayLooping();
            }
            else if(Score !=15)
            {
                if (c == 28)
                    musik.PlayLooping();
            }
            if (c < 10) label1.Text = "0"+c.ToString();
            else label1.Text = c.ToString();
            c--;
            if (c == -1)
            {
                timer1.Stop();
                if (Score >= 0 && Score <= 4)
                {
                    zero.Play();
                    Form4 obj = new Form4(@"E:\kolia\My PRojet\ds\milionare Ui\0..jpg");
                    obj.Show();
                    this.Close();
                }
                else if (Score >= 5 && Score <= 9)
                {
                    thaus.Play();
                    Form4 obj = new Form4(@"E:\kolia\My PRojet\ds\milionare Ui\Alf.jpg");
                    obj.Show();
                    this.Close();
                }
                else if (Score >= 10 && Score < 15)
                {
                    Form4 obj = new Form4(@"E:\kolia\My PRojet\ds\milionare Ui\32alf.jpg");
                    obj.Show();
                    this.Close();
                }
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        private void FirstAnswer_Click(object sender, EventArgs e)
        {

        }
        int Score = 0;
        bool answer1 = false,answer2=false,answer3=false,answer4=false;
        private void SecondAnswer_Click(object sender, EventArgs e)
        {
            if (y && second)
            {
                if (people)
                {
                    pictureBox1.Hide();
                    people = false;
                }
                label3.BackColor = Color.Orange;
                SecondAnswer.IdleFillColor = Color.Orange;
                SecondAnswer.ActiveFillColor = Color.Orange;
                if (SecondAnswer.ButtonText == answer)
                    answer2 = true;
                else
                    clickbutton2 = true;
                timer2.Start();
                timer1.Stop();
                x = false;
                y = false;
            }
        }

        private void FirstAnswer_Click_1(object sender, EventArgs e)
        {
            if (y && first)
            {
                if(people)
                {
                    pictureBox1.Hide();
                    people = false;
                }
                label2.BackColor = Color.Orange;
                FirstAnswer.IdleFillColor = Color.Orange;
                FirstAnswer.ActiveFillColor = Color.Orange;
                if (FirstAnswer.ButtonText == answer)
                    answer1 = true;
                else
                    clickbutton1 = true;
                timer2.Start();   
                timer1.Stop();
                x = false;
                y = false;
            }
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
           
        }

        private void ThirdAnswer_Click(object sender, EventArgs e)
        {
            if (y && third)
            {
                if (people)
                {
                    pictureBox1.Hide();
                    people = false;
                }
                label4.BackColor = Color.Orange;
                ThirdAnswer.IdleFillColor = Color.Orange;
                ThirdAnswer.ActiveFillColor = Color.Orange;
                if (ThirdAnswer.ButtonText == answer)
                    answer3 = true;
                else
                    clickbutton3 = true;
                timer2.Start();
                timer1.Stop();
                x = false;
                y = false;
            }
        }


        private void FourthAnsweer_Click(object sender, EventArgs e)
        {
            if (y && fourth)
            {
                if (people)
                {
                    pictureBox1.Hide();
                    people = false;
                }
                label5.BackColor = Color.Orange;
                FourthAnsweer.IdleFillColor = Color.Orange;
                FourthAnsweer.ActiveFillColor = Color.Orange;
                if (FourthAnsweer.ButtonText == answer)
                    answer4 = true;
                else
                    clickbutton4 = true;
                timer2.Start();
                timer1.Stop();
                x = false;
                y = false;
            }
        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
////////////////////////////////////////////check/////////////////////////////////////////////////////////
        private void timer2_Tick(object sender, EventArgs e)
        {
            s--;
            if (s == 0)
            {
                timer2.Stop();
           //////////////////////////////////button 1 //////////////////////////////////////////////////////
                if (answer1==true)
                {

                    label2.BackColor = Color.Lime;
                    FirstAnswer.IdleFillColor = Color.Lime;
                    FirstAnswer.ActiveFillColor = Color.Lime;
                    Score++;
                    timer3.Start();
                    answer1 = false;
                    if (Score == 1)
                        firstquestion.Play();
                    else if (Score == 2)
                        secondquestion.Play();
                    else if (Score == 3)
                        thirdquestion.Play();
                    else if (Score == 4)
                        fourthquestion.Play();
                    else if (Score == 5)
                        fifthquestion.Play();
                    else if (Score == 6)
                        sixquestion.Play();
                    else if (Score == 7)
                        sevenquestion.Play();
                    else if (Score == 8)
                        eightquestion.Play();
                    else if (Score == 9)
                        ninequestion.Play();
                    else if (Score == 10)
                        tenquestion.Play();
                    else if (Score == 11)
                        elevenquestion.Play();
                    else if (Score == 14)
                        fourteenquestion.Play();
                    else if (Score == 15)
                        fifteenquestion.Play();
                }
                else if (answer2 == true)
                {
                    label3.BackColor = Color.Lime;
                    SecondAnswer.IdleFillColor = Color.Lime;
                    SecondAnswer.ActiveFillColor = Color.Lime;
                    Score++;
                    timer3.Start();
                    answer2 = false;
                    if (Score == 1)
                        firstquestion.Play();
                    else if (Score == 2)
                        secondquestion.Play();
                    else if (Score == 3)
                        thirdquestion.Play();
                    else if (Score == 4)
                        fourthquestion.Play();
                    else if (Score == 5)
                        fifthquestion.Play();
                    else if (Score == 6)
                        sixquestion.Play();
                    else if (Score == 7)
                        sevenquestion.Play();
                    else if (Score == 8)
                        eightquestion.Play();
                    else if (Score == 10)
                        tenquestion.Play();
                    else if (Score == 11)
                        elevenquestion.Play();
                    else if (Score == 14)
                        fourteenquestion.Play();
                    else if (Score == 15)
                        fifteenquestion.Play();
                }
                else if (answer3 == true)
                {
                    label4.BackColor = Color.Lime;
                    ThirdAnswer.IdleFillColor = Color.Lime;
                    ThirdAnswer.ActiveFillColor = Color.Lime;
                    Score++;
                    timer3.Start();
                    answer3 = false;
                    if (Score == 1)
                        firstquestion.Play();
                    else if (Score == 2)
                        secondquestion.Play();
                    else if (Score == 3)
                        thirdquestion.Play();
                    else if (Score == 4)
                        fourthquestion.Play();
                    else if (Score == 5)
                        fifthquestion.Play();
                    else if (Score == 6)
                        sixquestion.Play();
                    else if (Score == 7)
                        sevenquestion.Play();
                    else if (Score == 8)
                        eightquestion.Play();
                    else if (Score == 10)
                        tenquestion.Play();
                    else if (Score == 11)
                        elevenquestion.Play();
                    else if (Score == 14)
                        fourteenquestion.Play();
                    else if (Score == 15)
                        fifteenquestion.Play();
                }
                else if (answer4 == true)
                {
                    label5.BackColor = Color.Lime;
                    FourthAnsweer.IdleFillColor = Color.Lime;
                    FourthAnsweer.ActiveFillColor = Color.Lime;
                    Score++;
                    timer3.Start();
                    answer4 = false;
                    if (Score == 1)
                        firstquestion.Play();
                    else if (Score == 2)
                        secondquestion.Play();
                    else if (Score == 3)
                        thirdquestion.Play();
                    else if (Score == 4)
                        fourthquestion.Play();
                    else if (Score == 5)
                        fifthquestion.Play();
                    else if (Score == 6)
                        sixquestion.Play();
                    else if (Score == 7)
                        sevenquestion.Play();
                    else if (Score == 8)
                        eightquestion.Play();
                    else if (Score == 10)
                        tenquestion.Play();
                    else if (Score == 11)
                        elevenquestion.Play();
                    else if (Score == 14)
                        fourteenquestion.Play();
                    else if (Score == 15)
                        fifteenquestion.Play();
                }
    ////////////////////////////////////////////////////////////////////////button1 ////////////////////////////////////
                if (clickbutton1==true)
                {
                    fals.Play();
                    label2.BackColor = Color.Red;
                    FirstAnswer.IdleFillColor = Color.Red;
                    FirstAnswer.ActiveFillColor = Color.Red;
                    timer7.Start();
                    timer4.Start();
                    clickbutton1 = false;
                }
/////////////////////////////////////////////////////////////////button 2 //////////////////////////////////////
                else if(clickbutton2==true)
                {
                    fals.Play();
                    label3.BackColor = Color.Red;
                    SecondAnswer.IdleFillColor = Color.Red;
                    SecondAnswer.ActiveFillColor = Color.Red;
                    timer7.Start();
                    timer4.Start();
                    clickbutton2 = false;
                }
              ///////////////////////////////button3////////////////////////////////////////////////////
                else if(clickbutton3==true)
                {
                    fals.Play();
                    label4.BackColor = Color.Red;
                    ThirdAnswer.IdleFillColor = Color.Red;
                    ThirdAnswer.ActiveFillColor = Color.Red;
                    timer7.Start();
                    timer4.Start();
                    clickbutton3 = false;
                }
        /////////////////////button4//////////////////////////////////////////////////////
                else if(clickbutton4==true)
                {
                    fals.Play();
                    label5.BackColor = Color.Red;
                    FourthAnsweer.IdleFillColor = Color.Red;
                    FourthAnsweer.ActiveFillColor = Color.Red;
                    timer7.Start();     
                    timer4.Start();
                    clickbutton4 = false;
                }
                
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            
            d--;
            if (d == -1)
            {
                if (Score == 1)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\1.png");
                else if (Score == 2)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\2.png");
                else if (Score == 3)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\3.png");
                else if (Score == 4)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\4.png");
                else if (Score == 5)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\5.png");
                else if (Score == 6)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\6.png");
                else if (Score == 7)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\7.png");
                else if (Score == 8)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\8.png");
                else if (Score == 9)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\9.png");
                else if (Score == 10)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\10.png");
                else if (Score == 11)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\11.png");
                else if (Score == 12)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\12.png");
                else if (Score == 13)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\13.png");
                else if (Score == 14)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\14.png");
                else if (Score == 15)
                    Score_0.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\score\15.png");
                
                if (Score != 15)
                {
                    FirstAnswer.IdleFillColor = Color.Black;
                    FirstAnswer.ActiveFillColor = Color.Black;
                    
                    label2.BackColor = Color.Black;

                    SecondAnswer.IdleFillColor = Color.Black;
                    SecondAnswer.ActiveFillColor = Color.Black;
                    
                    label3.BackColor = Color.Black;
                    
                    ThirdAnswer.IdleFillColor = Color.Black;
                    ThirdAnswer.ActiveFillColor = Color.Black;
                    
                    label4.BackColor = Color.Black;
                    
                    FourthAnsweer.IdleFillColor = Color.Black;
                    FourthAnsweer.ActiveFillColor = Color.Black;
                    
                    label5.BackColor = Color.Black;
                    c = 30;
                    s = 3;
                    d = 2;
                    if (Score == 14)
                        d = 7;
                    timer1.Start();
                    timer3.Stop();
                    y = true;
                    x = true;
                    first = true;
                    second = true;
                    third = true;
                    fourth = true;

                    if (Score >= 1 && Score <=5)
                    {
                        a = rnd.Next(1, 40);
                        for (int i = 0; i < comrandom.Count(); i++)
                        {
                            if (comrandom[i] == a)
                            {
                                a = rnd.Next(1, 40);
                                i = 0;
                            }
                        }
                        comrandom.Add(a);
                    }
                    else if (Score >= 6 && Score <= 10)
                    {
                        a = rnd.Next(41, 80);
                        for (int i = 0; i < comrandom.Count(); i++)
                        {
                            if (comrandom[i] == a)
                            {
                                a = rnd.Next(41, 80);
                                i = 0;
                            }
                        }
                        comrandom.Add(a);
                    }
                    else if (Score >= 11 && Score <= 15)
                    {
                        a = rnd.Next(81, 120);
                        for (int i = 0; i < comrandom.Count(); i++)
                        {
                            if (comrandom[i] == a)
                            {
                                a = rnd.Next(81, 120);
                                i = 0;
                            }
                        }
                        comrandom.Add(a);
                    }
                    Question.ButtonText = map1[a][0];
                    answer = map1[a][1];
                    FirstAnswer.ButtonText = map2[a][0];
                    SecondAnswer.ButtonText = map2[a][1];
                    ThirdAnswer.ButtonText = map2[a][2];
                    FourthAnsweer.ButtonText = map2[a][3];
                    
                }
                else
                {
                    timer3.Stop();
                    Form7 obj = new Form7();///milion
                    obj.Show();
                    this.Close();
                }
            }
        }

        private void flatClose1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }


        private void timer4_Tick_1(object sender, EventArgs e)
        {
            m--;
            if (m == -1)
            {
                timer4.Stop();
                if (Score >= 0 && Score <= 4)
                {
                    zero.Play();
                    Form4 obj = new Form4(@"E:\kolia\My PRojet\ds\milionare Ui\0..jpg");
                    obj.Show();
                    this.Close();
                }
                else if (Score >= 5 && Score <= 9)
                {
                    thaus.Play();
                    Form4 obj = new Form4(@"E:\kolia\My PRojet\ds\milionare Ui\Alf.jpg");
                    obj.Show();
                    this.Close();
                }
                else if (Score >= 10 && Score < 15)
                {
                    Form4 obj = new Form4(@"E:\kolia\My PRojet\ds\milionare Ui\32alf.jpg");
                    obj.Show();
                    this.Close();
                }
            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if(b==3)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\أ.jpg");
            else if(b==2)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\ب.jpg");
            else if(b==1)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\ج.jpg");
            else if(b==0)
                pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\د.jpg");
            else if (b == -1)
            {
                if (FirstAnswer.ButtonText == answer)
                {
                    pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\أ.jpg");
                   // audience.Stop();
                }
                else if (SecondAnswer.ButtonText == answer)
                {
                    pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\ب.jpg");
                     //audience.Stop();
                }
                else if (ThirdAnswer.ButtonText == answer)
                {
                    pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\ج.jpg");
                   // audience.Stop();
                }
                else
                {
                    pictureBox1.Image = Image.FromFile(@"E:\kolia\My PRojet\ds\milionare Ui\د.jpg");
                   // audience.Stop();
                }
                timer5.Stop();
            }
            b--;
        }
        private void timer6_Tick(object sender, EventArgs e)
        {
            if (p == -1)
            {
                
                musik.PlayLooping();
                if (Score >= 0 && Score <= 9)
                {
                    if (FirstAnswer.ButtonText == answer)
                    {
                        contact.Stop();
                        Form5 obj = new Form5("( أ )");
                        obj.Show();
                    }
                    else if (SecondAnswer.ButtonText == answer)
                    {
                        contact.Stop();
                        Form5 obj = new Form5("( ب )");
                        obj.Show();
                    }
                    else if (ThirdAnswer.ButtonText == answer)
                    {
                        contact.Stop();
                        Form5 obj = new Form5("( ج )");
                        obj.Show();
                    }
                    else
                    {
                        contact.Stop();
                        Form5 obj = new Form5("( د )");
                        obj.Show();
                    }
                }
                else
                {
                    contact.Stop();
                    Form8 obj = new Form8();
                    obj.Show();
                }
            }
            p--;
        }
        private void timer7_Tick(object sender, EventArgs e)
        {
            if (n == -1) {
                FirstAnswer.IdleFillColor = Color.Black;
                FirstAnswer.ActiveFillColor = Color.Black;

                label2.BackColor = Color.Black;

                SecondAnswer.IdleFillColor = Color.Black;
                SecondAnswer.ActiveFillColor = Color.Black;

                label3.BackColor = Color.Black;
                
                ThirdAnswer.IdleFillColor = Color.Black;
                ThirdAnswer.ActiveFillColor = Color.Black;

                label4.BackColor = Color.Black;

                FourthAnsweer.IdleFillColor = Color.Black;
                FourthAnsweer.ActiveFillColor = Color.Black;

                label5.BackColor = Color.Black;
                
                if (FirstAnswer.ButtonText == answer)
                {
                    FirstAnswer.IdleFillColor = Color.Lime;
                    FirstAnswer.ActiveFillColor = Color.Lime;
                    label2.BackColor = Color.Lime;
                }
                else if (SecondAnswer.ButtonText == answer)
                {
                    label3.BackColor = Color.Lime;
                    SecondAnswer.IdleFillColor = Color.Lime;
                    SecondAnswer.ActiveFillColor = Color.Lime;
                }
                else if (ThirdAnswer.ButtonText == answer)
                {
                    label4.BackColor = Color.Lime;
                    ThirdAnswer.IdleFillColor = Color.Lime;
                    ThirdAnswer.ActiveFillColor = Color.Lime;
                }
                else if (FourthAnsweer.ButtonText == answer)
                {
                    label5.BackColor = Color.Lime;
                    FourthAnsweer.IdleFillColor = Color.Lime;
                    FourthAnsweer.ActiveFillColor = Color.Lime;
                }
            }
            n--;
        }
    }
}