﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace milionir
{

    public partial class Form8 : Form
    {
        SoundPlayer musik = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\musik.wav");
        SoundPlayer contact = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\contact.wav");
        public Form8()
        {
            InitializeComponent();
            contact.PlayLooping();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            contact.Stop();
            musik.PlayLooping();
            this.Close();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }
    }
}
