﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace milionir
{
    public partial class Form3 : Form
    {
        SoundPlayer start = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\audience.wav");
        SoundPlayer replace = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\per.wav");
        public Form3()
        {
            InitializeComponent();
            start.PlayLooping();
        }

        private void flatButton3_Click(object sender, EventArgs e)
        {

        }

        private void flatButton2_Click(object sender, EventArgs e)
        {
           
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            start.Stop();
            replace.PlayLooping();
            this.Close();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
