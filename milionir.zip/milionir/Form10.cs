﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace milionir
{
    public partial class Form10 : Form
    {
        SoundPlayer fire1 = new SoundPlayer(@"E:\kolia\My PRojet\ds\milionare Ui\fire10.wav");
        public Form10()
        {
            InitializeComponent();
            fire1.PlayLooping();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            fire1.Stop();
            Form1 obj = new Form1();
            obj.Show();
            this.Close();
        }

        private void Form10_Load(object sender, EventArgs e)
        {

        }
    }
}
